POOJA MALHOTRA AUTHOR WEBSITE

Open index.html to view the website.

Pages:
- index.html
- about.html
- books.html
- book-close-enough.html
- book-communication.html
- book-training.html
- book-instructional-design.html
- book-manifestation.html
- contact.html

All supplied screenshot images were cropped into the assets/ folder and used as the book/author imagery.
